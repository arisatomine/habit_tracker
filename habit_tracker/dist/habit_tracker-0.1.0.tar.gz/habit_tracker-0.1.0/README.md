# Habit Tracker

This is a simple habit tracker application.

## Installation

````bash
pip install habit_tracker

# Add a new habit
habits add "Exercise"

# List all habits
habits list

# Mark a habit as done for today
habits done 1


### LICENSE ファイル
MITライセンスファイルです。

```text
MIT License

...

````
